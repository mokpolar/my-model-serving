# my-model-serving
모델 서빙 테스트용 코드


## set virtual environment

```bash
# install virtualenv
pip install virtualenv

# create virtualenv
virtualenv .venv --python=3.9

# activate
source .venv/bin/activate

# install libraries
pip install -r requirements.txt

# deactivate
deactivate
```