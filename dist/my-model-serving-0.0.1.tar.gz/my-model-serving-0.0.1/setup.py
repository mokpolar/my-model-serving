from setuptools import setup, find_packages

setup(
    name="my-model-serving",
    version="0.0.1",
    author="mokpolar",
    author_email="beholder16@gmail.com",
    url="",
    description="package for my model serving",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)